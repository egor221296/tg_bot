# config/constants.py

# Состояния для ConversationHandler
START_ROUTES = 0
CREATE_TEST = 1
ANSWER_TEST = 2
EDIT_ANSWERS = 3
VIEW_RESULTS = 4

# Callback Data константы для кнопок
CB_CREATE_TEST = "create_test"
CB_TAKE_TEST = "take_test"
CB_MY_RESULTS = "my_results"
CB_MY_LINK = "my_link"
CB_SHARE_TEST = "share_test"

CB_BACK = "back"
CB_TEST_TYPE_PREFIX = "test_"
CB_ANSWER_PREFIX = "answer_"
CB_EDIT_PREFIX = "edit_"
CB_CONFIRM = "confirm_test"
CB_NEXT = "next"
CB_START_TEST = "start_test"
CB_VIEW_ANSWERS = "view_answers"
CB_SHARE_RESULTS = "share_results"