# Токены, подключение к БД

# config/settings.py
from dotenv import load_dotenv
import os

# Загружаем переменные окружения из файла .env
load_dotenv()

# Список токенов ботов (через запятую в .env)
BOT_TOKENS = os.getenv("BOT_TOKENS", "").split(",")

# Параметры базы данных
MONGO_URI = os.getenv("MONGO_URI")
DB_NAME = os.getenv("DB_NAME", "smartbot_hub")

# Базовый URL для изображений (при необходимости)
IMAGE_BASE_URL = os.getenv("IMAGE_BASE_URL", "")

# Уровни дружбы для подсчета результатов теста
FRIENDSHIP_LEVELS = {
    (0, 20): "Просто знакомый 😐",
    (21, 40): "Приятель 😊",
    (41, 60): "Хороший друг 😎",
    (61, 80): "Лучший друг 🥳",
    (81, 100): "Родственная душа 💖"
}

# Время для отправки напоминаний (формат ЧЧ:ММ, разделенные запятой)
REMINDER_TIMES = os.getenv("REMINDER_TIMES", "10:00,18:00").split(",")

# Проверка на наличие токенов
if not BOT_TOKENS or BOT_TOKENS == ['']:
    raise ValueError("Переменная окружения BOT_TOKENS не задана в файле .env")