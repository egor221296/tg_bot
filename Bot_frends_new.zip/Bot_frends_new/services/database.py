# Работа с MongoDB

# services/database.py

from motor.motor_asyncio import AsyncIOMotorClient
from config.settings import MONGO_URI, DB_NAME

# Создание асинхронного клиента MongoDB
client = AsyncIOMotorClient(MONGO_URI)

# Подключение к базе данных
db = client[DB_NAME]

# Коллекции
users_collection = db["users"]
tests_collection = db["tests"]

# Здесь можно будет добавлять другие коллекции
# Например: friends_collection = db["friends"]