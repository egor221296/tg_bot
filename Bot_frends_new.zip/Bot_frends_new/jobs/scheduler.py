# Планировщик задач

# jobs/scheduler.py

from telegram.ext import ContextTypes
from config.settings import REMINDER_TIMES
import logging
import asyncio

logger = logging.getLogger(__name__)

# Функция отправки напоминания
async def send_reminder(context: ContextTypes.DEFAULT_TYPE) -> None:
    # Здесь можно получить список пользователей из базы и отправлять каждому
    logger.info("Выполняется отправка напоминаний пользователям.")
    # Например, можно отправить администратору тестовое сообщение
    if context.bot_data.get('admin_chat_id'):
        await context.bot.send_message(chat_id=context.bot_data['admin_chat_id'], text="Напоминание: загляни в бота! 📢")

# Функция для планирования напоминаний по расписанию
async def schedule_reminders(application) -> None:
    from apscheduler.triggers.cron import CronTrigger

    logger.info("Настройка напоминаний по расписанию...")

    for time_str in REMINDER_TIMES:
        hour, minute = map(int, time_str.split(":"))
        trigger = CronTrigger(hour=hour, minute=minute, timezone="UTC")  # Можем потом настроить часовой пояс

        application.job_queue.run_repeating(
            send_reminder,
            trigger=trigger,
            name=f"reminder_{hour}_{minute}",
        )

# jobs/scheduler.py (дополнительно)
from telegram import BotCommand
async def setup_bot_commands(context):
    await context.bot.set_my_commands([
        BotCommand("start", "Запустить бота"),
        BotCommand("help", "Помощь"),
        BotCommand("mylink", "Моя ссылка на тест"),
        BotCommand("results", "Мои результаты")
    ])

# Дополнительно: регулярная очистка устаревших данных или обслуживание базы
async def run_maintenance_tasks():
    while True:
        logger.info("Выполняется регулярная проверка состояния базы...")
        await asyncio.sleep(3600)  # Каждые 60 минут

