# Вспомогательные утилиты

# utils/helpers.py

from telegram import InlineKeyboardMarkup, InlineKeyboardButton

# Быстрая сборка клавиатуры из списка кортежей (текст кнопки, callback_data)
def build_inline_keyboard(buttons: list) -> InlineKeyboardMarkup:
    keyboard = [[InlineKeyboardButton(text, callback_data=data)] for text, data in buttons]
    return InlineKeyboardMarkup(keyboard)

# Пример использования:
# buttons = [("Кнопка 1", "callback_1"), ("Кнопка 2", "callback_2")]
# markup = build_inline_keyboard(buttons)