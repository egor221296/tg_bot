# Основной запуск бота

import logging
import asyncio
import os

from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ConversationHandler, Defaults
)
from telegram.constants import ParseMode

# Импорт настроек и подключения к базе данных
import config.settings

# Импорт обработчиков команд
from handlers.start import start, show_main_menu
from handlers.test_create import (
    create_test_start, handle_test_type_selection, handle_answer,
    handle_confirm_test, handle_next, handle_edit_question, complete_test
)
from handlers.test_answer import (
    start_taking_test, view_answers, share_results, handle_back_to_results
)
from handlers.common import (
    help_command, mylink_command, results_command, share_test, handle_back
)

# Импорт настроек состояний и констант (мы их создадим отдельно чуть позже, пока пропустим их)
from config.constants import (
    START_ROUTES, CREATE_TEST, ANSWER_TEST, EDIT_ANSWERS, VIEW_RESULTS,
    CB_CREATE_TEST, CB_TAKE_TEST, CB_MY_RESULTS, CB_MY_LINK, CB_SHARE_TEST,
    CB_BACK, CB_TEST_TYPE_PREFIX, CB_ANSWER_PREFIX, CB_EDIT_PREFIX,
    CB_CONFIRM, CB_NEXT, CB_START_TEST, CB_VIEW_ANSWERS, CB_SHARE_RESULTS
)

# Импорт задач
from jobs.scheduler import run_maintenance_tasks, setup_bot_commands

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def run_bot(token: str, n: int) -> None:
    defaults = Defaults(parse_mode=ParseMode.MARKDOWN)
    app = Application.builder().token(token).defaults(defaults).build()

    # Подключение обработчиков
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("mylink", mylink_command))
    app.add_handler(CommandHandler("results", results_command))

    start_routes_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(create_test_start, pattern=f"^{CB_CREATE_TEST}$"),
            CallbackQueryHandler(start_taking_test, pattern=f"^{CB_TAKE_TEST}$"),
            CallbackQueryHandler(share_results, pattern=f"^{CB_MY_RESULTS}$"),
            CallbackQueryHandler(show_my_link, pattern=f"^{CB_MY_LINK}$"),
            CallbackQueryHandler(share_test, pattern=f"^{CB_SHARE_TEST}$")
        ],
        states={
            START_ROUTES: [
                CallbackQueryHandler(create_test_start, pattern=f"^{CB_CREATE_TEST}$"),
                CallbackQueryHandler(start_taking_test, pattern=f"^{CB_TAKE_TEST}$"),
                CallbackQueryHandler(share_results, pattern=f"^{CB_MY_RESULTS}$"),
                CallbackQueryHandler(show_my_link, pattern=f"^{CB_MY_LINK}$"),
                CallbackQueryHandler(share_test, pattern=f"^{CB_SHARE_TEST}$"),
                CallbackQueryHandler(show_main_menu, pattern=f"^{CB_BACK}$")
            ]
        },
        fallbacks=[CommandHandler("start", start)],
        map_to_parent={ConversationHandler.END: ConversationHandler.END}
    )

    create_test_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(handle_test_type_selection, pattern=f"^{CB_TEST_TYPE_PREFIX}")],
        states={
            CREATE_TEST: [
                CallbackQueryHandler(handle_answer, pattern=f"^{CB_ANSWER_PREFIX}"),
                CallbackQueryHandler(handle_back, pattern=f"^{CB_BACK}$"),
                CallbackQueryHandler(handle_next, pattern=f"^{CB_NEXT}$")
            ],
            EDIT_ANSWERS: [
                CallbackQueryHandler(handle_edit_question, pattern=f"^{CB_EDIT_PREFIX}"),
                CallbackQueryHandler(handle_confirm_test, pattern=f"^{CB_CONFIRM}$")
            ]
        },
        fallbacks=[CommandHandler("start", start)],
        map_to_parent={ConversationHandler.END: START_ROUTES}
    )

    answer_test_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_taking_test, pattern=f"^{CB_START_TEST}$")],
        states={
            ANSWER_TEST: [
                CallbackQueryHandler(handle_answer, pattern=f"^{CB_ANSWER_PREFIX}"),
                CallbackQueryHandler(handle_back, pattern=f"^{CB_BACK}$"),
                CallbackQueryHandler(handle_next, pattern=f"^{CB_NEXT}$"),
                CallbackQueryHandler(complete_test, pattern=f"^{CB_CONFIRM}$")
            ],
            VIEW_RESULTS: [
                CallbackQueryHandler(view_answers, pattern=f"^{CB_VIEW_ANSWERS}$"),
                CallbackQueryHandler(share_results, pattern=f"^{CB_SHARE_RESULTS}$"),
                CallbackQueryHandler(handle_back_to_results, pattern=f"^{CB_BACK}$")
            ]
        },
        fallbacks=[CommandHandler("start", start)],
        map_to_parent={ConversationHandler.END: START_ROUTES}
    )

    app.add_handler(start_routes_handler)
    app.add_handler(create_test_handler)
    app.add_handler(answer_test_handler)

    app.job_queue.run_once(setup_bot_commands, 0)
    app.job_queue.run_once(lambda ctx: asyncio.create_task(run_maintenance_tasks()), 0)

    await app.initialize()
    await app.start()
    await app.updater.start_polling()
    logger.info(f"Бот {n} запущен.")
    try:
        await asyncio.Event().wait()
    finally:
        await app.updater.stop()
        await app.stop()
        await app.shutdown()

async def main() -> None:
    tokens_str = os.getenv("BOT_TOKENS", "")
    tokens = [t.strip() for t in tokens_str.split(",") if t.strip()]
    tasks = []
    for idx, token in enumerate(tokens, 1):
        tasks.append(asyncio.create_task(run_bot(token, idx)))
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())