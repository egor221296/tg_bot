# Создание тестов

# handlers/test_create.py

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Кнопки выбора типа теста
def get_test_type_menu():
    keyboard = [
        [InlineKeyboardButton("Тест на дружбу 🤝", callback_data="test_friendship")],
        [InlineKeyboardButton("Тест на любовь ❤️", callback_data="test_love")],
        [InlineKeyboardButton("Тест на знания 🧠", callback_data="test_knowledge")],
        [InlineKeyboardButton("Назад 🔙", callback_data="back")]
    ]
    return InlineKeyboardMarkup(keyboard)

# Старт создания теста
async def create_test_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "Выбери тип теста:",
        reply_markup=get_test_type_menu()
    )
    return 1  # Переход в состояние выбора теста

# Выбор типа теста
async def handle_test_type_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    selected_type = query.data

    context.user_data['test_type'] = selected_type
    context.user_data['questions'] = []
    context.user_data['current_question'] = 0

    await query.edit_message_text("Введите первый вопрос:")
    return 2  # Переход к вводу вопросов

# Ответ на вопрос теста
async def handle_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text
    context.user_data['questions'].append(text)
    context.user_data['current_question'] += 1

    if context.user_data['current_question'] >= 5:
        # Если введено 5 вопросов, идем дальше
        await update.message.reply_text(
            "Все вопросы введены! Теперь вы можете подтвердить создание теста.",
            reply_markup=get_confirm_test_menu()
        )
        return 3  # Переход к подтверждению
    else:
        await update.message.reply_text(f"Введите вопрос {context.user_data['current_question'] + 1}:")
        return 2  # Ожидание следующего вопроса

# Меню подтверждения теста
def get_confirm_test_menu():
    keyboard = [
        [InlineKeyboardButton("Подтвердить ✅", callback_data="confirm_test")],
        [InlineKeyboardButton("Редактировать ❌", callback_data="edit_test")]
    ]
    return InlineKeyboardMarkup(keyboard)

# Подтверждение теста
async def handle_confirm_test(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()

    # Здесь можно будет сохранить тест в базу данных (пока пропустим)
    await query.edit_message_text("Тест успешно создан! 🎉")
    return -1  # Завершение ConversationHandler


async def handle_next(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text("Следующий вопрос!")


async def handle_edit_question(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text("Редактирование вопроса!")


async def complete_test(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text("Тест завершён!")