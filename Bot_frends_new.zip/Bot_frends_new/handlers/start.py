# Команда /start

# handlers/start.py

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Главное меню кнопок
def get_main_menu():
    keyboard = [
        [InlineKeyboardButton("Создать тест", callback_data="create_test")],
        [InlineKeyboardButton("Пройти тест", callback_data="take_test")],
        [InlineKeyboardButton("Мои результаты", callback_data="my_results")],
        [InlineKeyboardButton("Моя ссылка", callback_data="my_link")],
        [InlineKeyboardButton("Поделиться тестом", callback_data="share_test")]
    ]
    return InlineKeyboardMarkup(keyboard)

# Обработчик команды /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    await update.message.reply_text(
        f"Привет, {user.first_name}!\n"
        "Я помогу тебе создать тест на дружбу 🧠.\n"
        "Выбери действие из меню:",
        reply_markup=get_main_menu()
    )

# Обработчик кнопки "Назад" на главную
async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "Ты вернулся в главное меню. Что хочешь сделать?",
        reply_markup=get_main_menu()
    )
    return 0  # Возвращаем в начальное состояние