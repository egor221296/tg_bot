# Ответы на тесты

# handlers/test_answer.py

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Старт прохождения теста
async def start_taking_test(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()

    # Здесь можно будет загружать тест из базы данных
    context.user_data['current_question_idx'] = 0
    context.user_data['user_answers'] = []

    await query.edit_message_text("Начинаем тест!\nВведите ответ на первый вопрос:")
    return 4  # Состояние ответов на тест

# Ответ на вопрос теста
async def handle_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    text = update.message.text
    context.user_data['user_answers'].append(text)
    context.user_data['current_question_idx'] += 1

    if context.user_data['current_question_idx'] >= 5:
        await update.message.reply_text(
            "Тест завершен! 🎉",
            reply_markup=get_test_result_menu()
        )
        return 5  # Переход к просмотру результатов
    else:
        await update.message.reply_text(f"Введите ответ на вопрос {context.user_data['current_question_idx'] + 1}:")
        return 4  # Ожидание следующего ответа

# Меню после завершения теста
def get_test_result_menu():
    keyboard = [
        [InlineKeyboardButton("Посмотреть ответы 👀", callback_data="view_answers")],
        [InlineKeyboardButton("Поделиться результатом 📤", callback_data="share_results")],
        [InlineKeyboardButton("Назад 🔙", callback_data="back")]
    ]
    return InlineKeyboardMarkup(keyboard)

# Просмотр ответов
async def view_answers(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()

    answers = context.user_data.get('user_answers', [])
    text = "\n".join([f"{idx+1}. {ans}" for idx, ans in enumerate(answers)])

    await query.edit_message_text(f"Твои ответы:\n{text}")
    return 5

# Поделиться результатом
async def share_results(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()

    await query.edit_message_text(
        "Поделись своим результатом с друзьями! 🔥\n"
        "Просто пересылай это сообщение им."
    )
    return 5

# Назад к результатам
async def handle_back_to_results(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()

    await query.edit_message_text(
        "Ты вернулся к результатам теста.",
        reply_markup=get_test_result_menu()
    )
    return 5