# Общие обработчики

# handlers/common.py

from telegram import Update
from telegram.ext import ContextTypes


async def handle_back(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text("Вы вернулись назад.")

# Команда /help
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "🆘 Помощь:\n"
        "/start — начать заново\n"
        "/mylink — получить ссылку на свой тест\n"
        "/results — посмотреть свои результаты\n"
        "/help — помощь"
    )

# Показать мою ссылку на тест
async def mylink_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    # Формируем ссылку на прохождение теста пользователя
    link = f"https://t.me/{context.bot.username}?start={user.id}"
    await update.message.reply_text(
        f"🔗 Вот твоя личная ссылка на тест:\n{link}"
    )

# Показать мои результаты
async def results_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    # Здесь можно будет загружать реальные результаты из базы данных
    await update.message.reply_text(
        f"📊 Результаты для @{user.username or user.first_name}:\n"
        "Пока здесь пусто, но скоро здесь будут твои достижения!"
    )

# Кнопка "Поделиться тестом" после прохождения
async def share_test(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    link = f"https://t.me/{context.bot.username}?start={query.from_user.id}"
    await query.edit_message_text(
        f"🔗 Поделись своим тестом с друзьями:\n{link}"
    )